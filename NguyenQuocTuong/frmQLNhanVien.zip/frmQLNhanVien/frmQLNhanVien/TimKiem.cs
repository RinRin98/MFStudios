﻿using System;
using System.Data;

namespace frmQLNhanVien
{
    public class TimKiem
    {
        public TimKiem(string sql, object connection)
        {
        }
        public void Fill(DataTable dtbTimKiem)
        {
            throw new NotImplementedException();
        }
    }
}
